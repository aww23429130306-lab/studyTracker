# Academic Planner: Android app with widgets
Upload this zip to your GitHub repo (same name, planner-app.zip), then run Actions -> Build APK.
Widgets: Main countdown, Exam countdown (you pick the exam), To-do Today, To-do Upcoming, To-do Next.
Tick the circle next to a task on a to-do widget to complete it. Widgets can be resized.
To change the logo later, replace icon.png (square, 1024x1024 is best) and run the build again.
