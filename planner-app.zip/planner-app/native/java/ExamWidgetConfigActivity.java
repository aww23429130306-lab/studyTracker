package com.plandeck.app;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shown when the "Exam countdown" widget is added: lets the user pick which exam to count down to. */
public class ExamWidgetConfigActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        final int id = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
        float d = getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * d); box.setPadding(pad, pad, pad, pad);
        TextView title = new TextView(this);
        title.setText("Choose an exam"); title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, (int) (12 * d)); box.addView(title);
        JSONArray ex = Widgets.arr(Widgets.data(this), "exams");
        if (ex.length() == 0) {
            TextView t = new TextView(this);
            t.setText("No upcoming exams yet. Add one in the app, then add this widget again.");
            t.setTextSize(15); box.addView(t);
        }
        SimpleDateFormat f = new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault());
        for (int i = 0; i < ex.length(); i++) {
            final JSONObject e = ex.optJSONObject(i); if (e == null) continue;
            TextView row = new TextView(this);
            row.setText(e.optString("name") + "\n" + f.format(new Date(e.optLong("time"))));
            row.setTextSize(16); row.setMinHeight((int) (56 * d));
            row.setPadding(0, (int) (10 * d), 0, (int) (10 * d));
            row.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                getSharedPreferences(Widgets.PREFS, 0).edit()
                    .putString("exam_name_" + id, e.optString("name")).putLong("exam_time_" + id, e.optLong("time")).apply();
                final Activity self = ExamWidgetConfigActivity.this;
                setContentView(WidgetColorConfigActivity.picker(self, id, new Runnable() { public void run() {
                    ExamCountdownProvider.update(self, AppWidgetManager.getInstance(self), id);
                    Intent r = new Intent(); r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
                    setResult(RESULT_OK, r); finish();
                }}));
            }});
            box.addView(row);
        }
        ScrollView sv = new ScrollView(this); sv.addView(box); setContentView(sv);
    }
}
