package com.plandeck.app;
import android.content.ContentResolver;
import android.app.AppOpsManager;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileOutputStream;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.media.RingtoneManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;

@CapacitorPlugin(name = "WidgetBridge")
public class WidgetBridgePlugin extends Plugin {

    /** Web app sends {main, exams, tasks, updated}. Tasks already ticked on a widget stay hidden until the app has applied them. */
    @PluginMethod
    public void update(PluginCall call) {
        try {
            SharedPreferences p = getContext().getSharedPreferences(Widgets.PREFS, 0);
            JSONObject d = new JSONObject(call.getData().toString());
            JSONArray done = new JSONArray(p.getString("done", "[]"));
            if (done.length() > 0) {
                JSONArray t = Widgets.arr(d, "tasks"), keep = new JSONArray();
                for (int i = 0; i < t.length(); i++) {
                    JSONObject o = t.optJSONObject(i);
                    if (o != null && !Widgets.has(done, o.optString("id"))) keep.put(o);
                }
                d.put("tasks", keep);
            }
            p.edit().putString("data", d.toString()).apply();
        } catch (Exception e) { }
        Widgets.refreshAll(getContext());
        call.resolve();
    }

    /** Returns the ids of tasks completed from a widget and clears the list. */
    @PluginMethod
    public void takeDone(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences(Widgets.PREFS, 0);
        JSObject r = new JSObject();
        try { r.put("ids", new JSONArray(p.getString("done", "[]"))); } catch (Exception e) { r.put("ids", new JSONArray()); }
        p.edit().putString("done", "[]").apply();
        call.resolve(r);
    }

    /** Saves a PNG (base64, no prefix) into Pictures/AcademicPlanner so it shows in the gallery. */
    @PluginMethod
    public void saveImage(PluginCall call) {
        try {
            String data = call.getString("data"), name = call.getString("name", "academic-planner-plan.png");
            if (data == null) { call.reject("no data"); return; }
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            ContentResolver r = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AcademicPlanner");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) { call.reject("insert failed"); return; }
            OutputStream os = r.openOutputStream(uri);
            os.write(bytes); os.close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.Images.Media.IS_PENDING, 0);
                r.update(uri, done, null, null);
            }
            JSObject ok = new JSObject(); ok.put("uri", uri.toString()); call.resolve(ok);
        } catch (Exception e) { call.reject("save failed: " + e.getMessage()); }
    }

    private boolean hasUsage() {
        try {
            Context c = getContext();
            AppOpsManager a = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
            return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) { return false; }
    }
    private boolean hasOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(getContext()); }

    /** {usage, overlay, active, end, strict, mode} for the focus lock. */
    @PluginMethod
    public void lockStatus(PluginCall call) {
        JSObject r = new JSObject();
        r.put("usage", hasUsage()); r.put("overlay", hasOverlay());
        r.put("active", FocusLockService.active(getContext())); r.put("end", FocusLockService.endOf(getContext()));
        r.put("strict", FocusLockService.strictOn(getContext())); r.put("mode", FocusLockService.modeOf(getContext()));
        call.resolve(r);
    }

    /** Starts blocking until {end} (epoch ms). mode "all" or "sel" (with apps[]), optional strict. */
    @PluginMethod
    public void lockStart(PluginCall call) {
        Long end = call.getLong("end");
        if (end == null || end <= System.currentTimeMillis()) { call.reject("bad end time"); return; }
        if (!hasUsage() || !hasOverlay()) { call.reject("permissions"); return; }
        String mode = "sel".equals(call.getString("mode")) ? "sel" : "all";
        StringBuilder sb = new StringBuilder();
        com.getcapacitor.JSArray arr = call.getArray("apps");
        if (arr != null) for (int i = 0; i < arr.length(); i++) { String a = arr.optString(i); if (!a.isEmpty()) sb.append(a).append(','); }
        boolean strict = Boolean.TRUE.equals(call.getBoolean("strict", false));
        try { FocusLockService.start(getContext(), end, mode, sb.toString(), strict); call.resolve(); }
        catch (Exception e) { call.reject("could not start: " + e.getMessage()); }
    }

    @PluginMethod
    public void lockStop(PluginCall call) {
        if (FocusLockService.strictOn(getContext())) { call.reject("strict"); return; }
        FocusLockService.stop(getContext()); call.resolve();
    }

    @PluginMethod
    public void openLockSettings(PluginCall call) {
        try {
            Intent i = "overlay".equals(call.getString("which"))
                ? new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()))
                : new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i); call.resolve();
        } catch (Exception e) { call.reject("cannot open settings"); }
    }

    /** Installed apps that have a launcher icon: {apps:[{pkg,name}]}. */
    @PluginMethod
    public void listApps(PluginCall call) {
        try {
            android.content.pm.PackageManager pm = getContext().getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN, null); q.addCategory(Intent.CATEGORY_LAUNCHER);
            java.util.List<android.content.pm.ResolveInfo> l = pm.queryIntentActivities(q, 0);
            com.getcapacitor.JSArray out = new com.getcapacitor.JSArray();
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            for (android.content.pm.ResolveInfo r : l) {
                String pk = r.activityInfo.packageName;
                if (pk.equals(getContext().getPackageName()) || !seen.add(pk)) continue;
                JSObject o = new JSObject(); o.put("pkg", pk); o.put("name", String.valueOf(r.loadLabel(pm))); out.put(o);
            }
            JSObject res = new JSObject(); res.put("apps", out); call.resolve(res);
        } catch (Exception e) { call.reject("apps: " + e.getMessage()); }
    }

    /** Saves text (backups, calendar files) to Downloads/AcademicPlanner and optionally opens the share sheet. */
    @PluginMethod
    public void saveText(PluginCall call) {
        try {
            String name = call.getString("name", "academic-planner.txt"), mime = call.getString("mime", "text/plain"), text = call.getString("text");
            boolean share = Boolean.TRUE.equals(call.getBoolean("share", false));
            if (text == null) { call.reject("no data"); return; }
            Uri uri;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver r = getContext().getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name); v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/AcademicPlanner");
                uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) { call.reject("insert failed"); return; }
                OutputStream os = r.openOutputStream(uri); os.write(text.getBytes("UTF-8")); os.close();
            } else {
                java.io.File dir = new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "Academic Planner");
                dir.mkdirs();
                java.io.FileOutputStream os = new java.io.FileOutputStream(new java.io.File(dir, name));
                os.write(text.getBytes("UTF-8")); os.close();
                uri = null;
            }
            if (share && uri != null) {
                Intent s = new Intent(Intent.ACTION_SEND); s.setType(mime); s.putExtra(Intent.EXTRA_STREAM, uri);
                s.setClipData(android.content.ClipData.newRawUri(name, uri));
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent ch = Intent.createChooser(s, "Share " + name); ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(ch);
            }
            JSObject ok = new JSObject(); ok.put("path", "Downloads/AcademicPlanner/" + name); call.resolve(ok);
        } catch (Exception e) { call.reject("save failed: " + e.getMessage()); }
    }




    /** Sessions finished from the focus widget since the app last asked: {sessions:[{start,secs}]} */
    @PluginMethod
    public void focusTake(PluginCall call) {
        SharedPreferences p = getContext().getSharedPreferences(FocusWidgetProvider.PREFS, 0);
        FocusWidgetProvider.settle(getContext());
        JSObject r = new JSObject();
        try { r.put("sessions", new JSONArray(p.getString("done", "[]"))); } catch (Exception e) { r.put("sessions", new JSONArray()); }
        p.edit().putString("done", "[]").apply();
        FocusWidgetProvider.refresh(getContext());
        call.resolve(r);
    }

    /** Google sign-in: returns {idToken, email}. clientId is the Web client ID from Firebase. */
    @PluginMethod
    public void googleSignIn(PluginCall call) {
        String cid = call.getString("clientId");
        if (cid == null || cid.isEmpty()) { call.reject("missing client id"); return; }
        try {
            GoogleSignInOptions o = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(cid).requestEmail().build();
            final GoogleSignInClient gc = GoogleSignIn.getClient(getActivity(), o);
            final PluginCall pc = call;
            gc.signOut().addOnCompleteListener(getActivity(), new com.google.android.gms.tasks.OnCompleteListener<Void>() {
                @Override public void onComplete(Task<Void> t) { startActivityForResult(pc, gc.getSignInIntent(), "googleResult"); }
            });
        } catch (Exception e) { call.reject("google sign-in failed: " + e.getMessage()); }
    }

    @ActivityCallback
    private void googleResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            GoogleSignInAccount a = GoogleSignIn.getSignedInAccountFromIntent(result.getData()).getResult(ApiException.class);
            JSObject r = new JSObject();
            r.put("idToken", a.getIdToken()); r.put("email", a.getEmail());
            call.resolve(r);
        } catch (ApiException e) { call.reject("code " + e.getStatusCode()); }
        catch (Exception e) { call.reject("cancelled"); }
    }

    /** Reads the text in a photo (on the phone, no internet needed). data = base64 JPEG. Returns {text}. */
    @PluginMethod
    public void ocrImage(final PluginCall call) {
        final String b64 = call.getString("data");
        if (b64 == null || b64.isEmpty()) { call.reject("no image"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    byte[] raw = Base64.decode(b64, Base64.DEFAULT);
                    Bitmap bm = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                    if (bm == null) { call.reject("bad image"); return; }
                    TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    Text t = Tasks.await(rec.process(InputImage.fromBitmap(bm, 0)));
                    JSObject r = new JSObject(); r.put("text", t.getText()); call.resolve(r);
                } catch (Exception e) { call.reject("ocr failed: " + e.getMessage()); }
            }
        }).start();
    }

    /** Reads the text of every page of a PDF (up to 60 pages). data = base64 PDF. Sends ocrProgress {page,total}. */
    @PluginMethod
    public void ocrPdf(final PluginCall call) {
        final String b64 = call.getString("data");
        if (b64 == null || b64.isEmpty()) { call.reject("no pdf"); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                File f = null; ParcelFileDescriptor fd = null; PdfRenderer pr = null;
                try {
                    f = File.createTempFile("syl", ".pdf", getContext().getCacheDir());
                    FileOutputStream o = new FileOutputStream(f); o.write(Base64.decode(b64, Base64.DEFAULT)); o.close();
                    fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
                    pr = new PdfRenderer(fd);
                    int n = Math.min(pr.getPageCount(), 60);
                    TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < n; i++) {
                        PdfRenderer.Page pg = pr.openPage(i);
                        int w = 1600, h = Math.max(1, Math.round(pg.getHeight() * (w / (float) pg.getWidth())));
                        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        bm.eraseColor(0xFFFFFFFF);
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        pg.close();
                        Text t = Tasks.await(rec.process(InputImage.fromBitmap(bm, 0)));
                        sb.append(t.getText()).append("\n");
                        bm.recycle();
                        JSObject p = new JSObject(); p.put("page", i + 1); p.put("total", n);
                        WidgetBridgePlugin.this.notifyListeners("ocrProgress", p);
                    }
                    JSObject r = new JSObject(); r.put("text", sb.toString()); r.put("pages", n); call.resolve(r);
                } catch (Exception e) { call.reject("pdf failed: " + e.getMessage()); }
                finally {
                    try { if (pr != null) pr.close(); } catch (Exception x) { }
                    try { if (fd != null) fd.close(); } catch (Exception x) { }
                    if (f != null) f.delete();
                }
            }
        }).start();
    }
}
