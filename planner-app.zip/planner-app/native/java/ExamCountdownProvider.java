package com.plandeck.app;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class ExamCountdownProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }
    static void update(Context c, AppWidgetManager m, int id) {
        SharedPreferences p = c.getSharedPreferences(Widgets.PREFS, 0);
        String name = p.getString("exam_name_" + id, null);
        long time = p.getLong("exam_time_" + id, 0);
        if (name != null) {   // use the newest time if the exam was edited in the app
            JSONArray ex = Widgets.arr(Widgets.data(c), "exams");
            for (int i = 0; i < ex.length(); i++) {
                JSONObject e = ex.optJSONObject(i);
                if (e != null && name.equals(e.optString("name"))) { time = e.optLong("time"); break; }
            }
        }
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_countdown);
        Widgets.bindCountdown(c, rv, name == null ? "" : name, name == null ? 0 : time, Widgets.theme(c, id));
        if (name == null) rv.setTextViewText(R.id.w_name, "Remove and add the widget again");
        m.updateAppWidget(id, rv);
    }
    @Override public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = c.getSharedPreferences(Widgets.PREFS, 0).edit();
        for (int id : ids) { e.remove("exam_name_" + id); e.remove("exam_time_" + id); e.remove("theme_" + id); }
        e.apply();
    }
}
