package com.plandeck.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Home-screen focus timer: Start 25, Start 45 and Stop work without opening the app. Finished sessions are saved when the app next opens. */
public class FocusWidgetProvider extends AppWidgetProvider {
    static final String A_START = "com.plandeck.app.FW_START", A_STOP = "com.plandeck.app.FW_STOP", A_DONE = "com.plandeck.app.FW_DONE";
    static final String PREFS = "ap_focus";

    static SharedPreferences P(Context c) { return c.getSharedPreferences(PREFS, 0); }

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        settle(c);
        for (int id : ids) m.updateAppWidget(id, build(c, id));
    }

    @Override public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = c.getSharedPreferences(Widgets.PREFS, 0).edit();
        for (int id : ids) e.remove("theme_" + id);
        e.apply();
    }

    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        String a = i.getAction();
        if (A_START.equals(a)) start(c, i.getIntExtra("mins", 25));
        else if (A_STOP.equals(a)) stop(c);
        else if (A_DONE.equals(a)) done(c);
    }

    static PendingIntent send(Context c, String action, int code, int mins) {
        Intent i = new Intent(c, FocusWidgetProvider.class).setAction(action).putExtra("mins", mins);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static RemoteViews build(Context c, int id) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_focus);
        int th = Widgets.theme(c, id), acc = Widgets.ACC[th];
        rv.setInt(R.id.f_root, "setBackgroundResource", Widgets.BG[th]);
        rv.setTextColor(R.id.f_b25, acc); rv.setTextColor(R.id.f_b45, acc); rv.setTextColor(R.id.f_stop, acc);
        SharedPreferences p = P(c);
        long now = System.currentTimeMillis(), end = p.getLong("end", 0);
        rv.setOnClickPendingIntent(R.id.f_root, Widgets.open(c));
        if (end > now) {
            rv.setViewVisibility(R.id.f_btns, View.GONE);
            rv.setViewVisibility(R.id.f_stop, View.VISIBLE);
            String until = "Until " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(end));
            if (Build.VERSION.SDK_INT >= 24) {
                rv.setViewVisibility(R.id.f_chr, View.VISIBLE);
                rv.setChronometer(R.id.f_chr, SystemClock.elapsedRealtime() + (end - now), null, true);
                rv.setChronometerCountDown(R.id.f_chr, true);
                rv.setTextViewText(R.id.f_idle, until);
            } else rv.setTextViewText(R.id.f_idle, "Focusing  \u00b7  " + until);
            rv.setOnClickPendingIntent(R.id.f_stop, send(c, A_STOP, 2, 0));
        } else {
            rv.setViewVisibility(R.id.f_chr, View.GONE);
            rv.setViewVisibility(R.id.f_stop, View.GONE);
            rv.setViewVisibility(R.id.f_btns, View.VISIBLE);
            rv.setTextViewText(R.id.f_idle, "Ready to focus");
            rv.setOnClickPendingIntent(R.id.f_b25, send(c, A_START, 25, 25));
            rv.setOnClickPendingIntent(R.id.f_b45, send(c, A_START, 45, 45));
        }
        return rv;
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, FocusWidgetProvider.class))) m.updateAppWidget(id, build(c, id));
    }

    static void record(Context c, long start, long secs) {
        if (secs < 60) return;
        SharedPreferences p = P(c);
        try {
            JSONArray a = new JSONArray(p.getString("done", "[]"));
            a.put(new JSONObject().put("start", start).put("secs", secs));
            p.edit().putString("done", a.toString()).apply();
        } catch (Exception e) { }
    }

    /** A session whose end time passed while the phone was off or asleep is saved without a notification. */
    static void settle(Context c) {
        SharedPreferences p = P(c);
        long end = p.getLong("end", 0), start = p.getLong("start", 0);
        if (end > 0 && end <= System.currentTimeMillis()) {
            record(c, start, (end - start) / 1000);
            p.edit().putLong("end", 0).putLong("start", 0).apply();
        }
    }

    static AlarmManager am(Context c) { return (AlarmManager) c.getSystemService(Context.ALARM_SERVICE); }

    static void start(Context c, int mins) {
        settle(c);
        SharedPreferences p = P(c);
        long now = System.currentTimeMillis();
        if (p.getLong("end", 0) > now) return;
        long end = now + mins * 60000L;
        p.edit().putLong("start", now).putLong("end", end).apply();
        PendingIntent pi = send(c, A_DONE, 9101, 0);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am(c).canScheduleExactAlarms()) am(c).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi);
            else am(c).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi);
        } catch (Exception e) { try { am(c).set(AlarmManager.RTC_WAKEUP, end, pi); } catch (Exception x) { } }
        refresh(c);
    }

    static void stop(Context c) {
        SharedPreferences p = P(c);
        long end = p.getLong("end", 0), start = p.getLong("start", 0), now = System.currentTimeMillis();
        if (end > now) record(c, start, (now - start) / 1000);
        p.edit().putLong("end", 0).putLong("start", 0).apply();
        am(c).cancel(send(c, A_DONE, 9101, 0));
        refresh(c);
    }

    static void done(Context c) {
        SharedPreferences p = P(c);
        long end = p.getLong("end", 0), start = p.getLong("start", 0);
        if (end <= 0) return;
        record(c, start, (end - start) / 1000);
        p.edit().putLong("end", 0).putLong("start", 0).apply();
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("fw_done", "Focus sessions", NotificationManager.IMPORTANCE_DEFAULT));
                b = new Notification.Builder(c, "fw_done");
            } else b = new Notification.Builder(c);
            b.setSmallIcon(R.drawable.ic_stat_icon).setContentTitle("Focus session complete")
                .setContentText("Nice work. " + ((end - start) / 60000) + " minutes of focus done.")
                .setAutoCancel(true).setContentIntent(Widgets.open(c));
            nm.notify(7003, b.build());
        } catch (Exception e) { }
        refresh(c);
    }
}
