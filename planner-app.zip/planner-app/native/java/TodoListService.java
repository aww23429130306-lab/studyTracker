package com.plandeck.app;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;
import java.util.List;

public class TodoListService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext(), intent.getStringExtra("mode"), intent.getIntExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, 0));
    }

    static class Factory implements RemoteViewsFactory {
        final Context c; final String mode; final int wid; List<String[]> rows = new ArrayList<>();
        Factory(Context c, String mode, int wid) { this.c = c; this.wid = wid; this.mode = mode == null ? "today" : mode; }
        @Override public void onCreate() {}
        @Override public void onDestroy() {}
        @Override public void onDataSetChanged() { rows = Widgets.todoRows(c, mode); }
        @Override public int getCount() { return rows.size(); }
        @Override public RemoteViews getViewAt(int i) {
            if (i < 0 || i >= rows.size()) return null;
            String[] r = rows.get(i);
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_todo_item);
            rv.setTextViewText(R.id.i_title, r[1]);
            rv.setTextViewText(R.id.i_when, r[2]);
            rv.setTextColor(R.id.i_when, r[3].equals("1") ? 0xFFB3261E : 0xFF6B6477);
            rv.setInt(R.id.i_box, "setBackgroundResource", Widgets.CHK[Widgets.theme(c, wid)]);
            Intent f = new Intent(); f.putExtra("id", r[0]);
            rv.setOnClickFillInIntent(R.id.i_check, f);   // tapping the circle completes the task
            return rv;
        }
        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int i) { return i; }
        @Override public boolean hasStableIds() { return false; }
    }
}
