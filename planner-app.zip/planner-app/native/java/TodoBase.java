package com.plandeck.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

abstract class TodoBase extends AppWidgetProvider {
    abstract String mode();   // "today", "upcoming" or "next"

    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        String mode = mode();
        int n = Widgets.todoRows(c, mode).size();
        String title = mode.equals("today") ? "Today" : mode.equals("upcoming") ? "Upcoming" : "Next up";
        String empty = mode.equals("today") ? "Nothing due today \uD83C\uDF89" : "No tasks coming up";
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_todo);
            rv.setTextViewText(R.id.w_title, n == 0 ? title : title + "  \u00b7  " + n);
            rv.setTextViewText(R.id.w_empty, empty);
            rv.setTextColor(R.id.w_title, Widgets.ACC[Widgets.theme(c, id)]);
            Intent si = new Intent(c, TodoListService.class);
            si.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
            si.putExtra("mode", mode);
            si.setData(Uri.parse(si.toUri(Intent.URI_INTENT_SCHEME)));
            rv.setRemoteAdapter(R.id.w_list, si);
            rv.setEmptyView(R.id.w_list, R.id.w_empty);
            Intent tpl = new Intent(c, TaskActionReceiver.class);
            tpl.setAction("com.plandeck.app.TASK_DONE");
            rv.setPendingIntentTemplate(R.id.w_list, PendingIntent.getBroadcast(c, 0, tpl, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE));
            rv.setOnClickPendingIntent(R.id.w_root, Widgets.open(c));
            rv.setOnClickPendingIntent(R.id.w_title, Widgets.open(c));
            rv.setOnClickPendingIntent(R.id.w_empty, Widgets.open(c));
            m.updateAppWidget(id, rv);
            m.notifyAppWidgetViewDataChanged(id, R.id.w_list);
        }
    }
}
