package com.plandeck.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Handles a tap on a task's circle in a to-do widget: hides it now, tells the app next time it opens. */
public class TaskActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String id = i.getStringExtra("id");
        if (id == null || id.isEmpty()) return;
        SharedPreferences p = c.getSharedPreferences(Widgets.PREFS, 0);
        try {
            JSONArray done = new JSONArray(p.getString("done", "[]"));
            if (!Widgets.has(done, id)) done.put(id);
            JSONObject d = Widgets.data(c);
            JSONArray t = Widgets.arr(d, "tasks"), keep = new JSONArray();
            for (int k = 0; k < t.length(); k++) {
                JSONObject o = t.optJSONObject(k);
                if (o != null && !id.equals(o.optString("id"))) keep.put(o);
            }
            d.put("tasks", keep);
            p.edit().putString("done", done.toString()).putString("data", d.toString()).apply();
        } catch (Exception e) { }
        Widgets.refreshAll(c);
    }
}
