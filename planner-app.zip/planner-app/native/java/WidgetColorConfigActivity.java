package com.plandeck.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Shown when a widget is added (or reconfigured): pick the widget colour. */
public class WidgetColorConfigActivity extends Activity {
    private static final int[] START = { 0xFF5E35B1, 0xFF0D47A1, 0xFF00695C, 0xFFD84315, 0xFFAD1457, 0xFF0B132B, 0xFF8A6500, 0xFF263238 };
    private static final int[] END = { 0xFF9575CD, 0xFF42A5F5, 0xFF4DB6AC, 0xFFFFB74D, 0xFFF48FB1, 0xFF3A506B, 0xFFE0A82E, 0xFF78909C };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        final int id = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
        final Activity self = this;
        setContentView(picker(this, id, new Runnable() { public void run() { finishOk(self, id); } }));
    }

    static void finishOk(Activity a, int id) {
        refresh(a, id);
        Intent r = new Intent(); r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        a.setResult(RESULT_OK, r); a.finish();
    }

    /** Redraws one widget right away with its new colour. */
    static void refresh(Context c, int id) {
        try {
            AppWidgetProviderInfo info = AppWidgetManager.getInstance(c).getAppWidgetInfo(id);
            if (info == null) return;
            Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE).setComponent(info.provider);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{ id });
            c.sendBroadcast(i);
        } catch (Exception e) { }
    }

    /** The colour grid. Choosing a colour stores it for this widget and runs `done`. */
    static View picker(final Activity a, final int id, final Runnable done) {
        final float d = a.getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (22 * d); box.setPadding(pad, pad, pad, pad);
        TextView t = new TextView(a);
        t.setText("Choose a colour"); t.setTextSize(20); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 0, 0, (int) (16 * d)); box.addView(t);
        LinearLayout row = null;
        for (int i = 0; i < START.length; i++) {
            if (i % 4 == 0) {
                row = new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, 0, 0, (int) (14 * d)); box.addView(row);
            }
            final int idx = i;
            TextView sw = new TextView(a);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ START[i], END[i] });
            g.setCornerRadius(16 * d); sw.setBackground(g);
            sw.setText(Widgets.THEME_NAMES[i]); sw.setTextColor(Color.WHITE); sw.setTextSize(11); sw.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (64 * d), 1f);
            lp.setMargins((int) (4 * d), 0, (int) (4 * d), 0); sw.setLayoutParams(lp);
            sw.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                a.getSharedPreferences(Widgets.PREFS, 0).edit().putInt("theme_" + id, idx).apply();
                done.run();
            }});
            row.addView(sw);
        }
        TextView same = new TextView(a);
        same.setText("Use the colour from the app"); same.setTextSize(16); same.setGravity(Gravity.CENTER);
        same.setTextColor(0xFF5E35B1); same.setTypeface(null, Typeface.BOLD);
        same.setPadding(0, (int) (14 * d), 0, (int) (6 * d));
        same.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            a.getSharedPreferences(Widgets.PREFS, 0).edit().remove("theme_" + id).apply();
            done.run();
        }});
        box.addView(same);
        ScrollView sv = new ScrollView(a); sv.addView(box);
        return sv;
    }
}
