package com.plandeck.app;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class MainCountdownProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        JSONObject main = Widgets.data(c).optJSONObject("main");
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_countdown);
            Widgets.bindCountdown(c, rv, main == null ? "" : main.optString("name"), main == null ? 0 : main.optLong("time"), Widgets.theme(c, id));
            m.updateAppWidget(id, rv);
        }
    }
}
