package com.plandeck.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

final class Widgets {
    static boolean has(JSONArray a, String id) {
        for (int i = 0; i < a.length(); i++) if (id.equals(a.optString(i))) return true;
        return false;
    }

    /** Rows for a to-do widget: {id, title, when, overdue("1"/"0")} */
    static java.util.List<String[]> todoRows(Context c, String mode) {
        java.util.List<String[]> rows = new java.util.ArrayList<>();
        long now = System.currentTimeMillis(), sod = startOfDay(now), eod = sod + 86400000L - 1;
        SimpleDateFormat tf = new SimpleDateFormat("h:mm a", Locale.getDefault()), df = new SimpleDateFormat("EEE, h:mm a", Locale.getDefault());
        JSONArray all = arr(data(c), "tasks");
        for (int i = 0; i < all.length(); i++) {
            JSONObject t = all.optJSONObject(i); if (t == null) continue;
            long due = t.optLong("due");
            boolean ok = mode.equals("today") ? due <= eod : mode.equals("upcoming") ? (due > eod && due <= eod + 7 * 86400000L) : true;
            if (!ok) continue;
            boolean over = due < sod;
            String when = over ? "Overdue" : due <= eod ? "Today, " + tf.format(new Date(due)) : df.format(new Date(due));
            rows.add(new String[]{ t.optString("id"), t.optString("t"), when, over ? "1" : "0" });
            if (rows.size() >= 40) break;
        }
        return rows;
    }

    static final String PREFS = "ap_widget";
    static final Class<?>[] ALL = { MainCountdownProvider.class, ExamCountdownProvider.class,
        TodayTodoProvider.class, UpcomingTodoProvider.class, NextTodoProvider.class, NextExamProvider.class };

    static final int[] BG = { R.drawable.bg_w0, R.drawable.bg_w1, R.drawable.bg_w2, R.drawable.bg_w3, R.drawable.bg_w4, R.drawable.bg_w5, R.drawable.bg_w6, R.drawable.bg_w7 };
    static final int[] CHK = { R.drawable.bg_chk0, R.drawable.bg_chk1, R.drawable.bg_chk2, R.drawable.bg_chk3, R.drawable.bg_chk4, R.drawable.bg_chk5, R.drawable.bg_chk6, R.drawable.bg_chk7 };
    static final int[] ACC = { 0xFF5E35B1, 0xFF0D47A1, 0xFF00695C, 0xFFD84315, 0xFFAD1457, 0xFF0B132B, 0xFF8A6500, 0xFF263238 };
    static final String[] THEME_NAMES = { "Violet", "Ocean", "Emerald", "Sunset", "Rose", "Midnight", "Gold", "Graphite" };

    /** The colour theme of one widget: its own choice, or the colour picked in the app. */
    static int theme(Context c, int widgetId) {
        int t = c.getSharedPreferences(PREFS, 0).getInt("theme_" + widgetId, -1);
        if (t < 0 || t >= BG.length) t = data(c).optInt("theme", 0);
        return Math.max(0, Math.min(BG.length - 1, t));
    }

    static JSONObject data(Context c) {
        try { return new JSONObject(c.getSharedPreferences(PREFS, 0).getString("data", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    static PendingIntent open(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (i == null) i = new Intent();
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void refreshAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> k : ALL) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, k));
            if (ids.length == 0) continue;
            Intent i = new Intent(c, k);
            i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            c.sendBroadcast(i);
        }
    }

    static long startOfDay(long t) {
        Calendar a = Calendar.getInstance(); a.setTimeInMillis(t);
        a.set(Calendar.HOUR_OF_DAY, 0); a.set(Calendar.MINUTE, 0); a.set(Calendar.SECOND, 0); a.set(Calendar.MILLISECOND, 0);
        return a.getTimeInMillis();
    }

    /** Fills a countdown widget. time <= 0 means "nothing to show". */
    static void bindCountdown(Context c, RemoteViews rv, String name, long time, int theme) {
        rv.setInt(R.id.w_root, "setBackgroundResource", BG[theme]);
        long now = System.currentTimeMillis();
        if (time <= 0) {
            rv.setTextViewText(R.id.w_big, "-"); rv.setTextViewText(R.id.w_unit, "No exam set");
            rv.setTextViewText(R.id.w_name, "Open the app to add one"); rv.setTextViewText(R.id.w_date, "");
        } else if (time <= now) {
            rv.setTextViewText(R.id.w_big, "\u2713"); rv.setTextViewText(R.id.w_unit, "Exam over");
            rv.setTextViewText(R.id.w_name, name); rv.setTextViewText(R.id.w_date, "");
        } else {
            long days = Math.round((startOfDay(time) - startOfDay(now)) / 86400000.0);
            if (days <= 0) {
                long hrs = Math.max(1, (long) Math.ceil((time - now) / 3600000.0));
                rv.setTextViewText(R.id.w_big, String.valueOf(hrs));
                rv.setTextViewText(R.id.w_unit, hrs == 1 ? "hour left" : "hours left");
            } else {
                rv.setTextViewText(R.id.w_big, String.valueOf(days));
                rv.setTextViewText(R.id.w_unit, days == 1 ? "day left" : "days left");
            }
            rv.setTextViewText(R.id.w_name, name);
            rv.setTextViewText(R.id.w_date, new SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(new Date(time)));
        }
        rv.setOnClickPendingIntent(R.id.w_root, open(c));
    }

    static JSONArray arr(JSONObject o, String k) {
        JSONArray a = o.optJSONArray(k); return a == null ? new JSONArray() : a;
    }
}
