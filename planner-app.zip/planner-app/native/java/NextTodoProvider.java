package com.plandeck.app;
public class NextTodoProvider extends TodoBase { @Override String mode() { return "next"; } }
