package com.plandeck.app;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

/** Always shows the next upcoming exam and moves to the following one by itself when an exam day has passed. */
public class NextExamProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        JSONArray ex = Widgets.arr(Widgets.data(c), "exams");
        long now = System.currentTimeMillis(), best = 0; String name = "";
        for (int i = 0; i < ex.length(); i++) {
            JSONObject e = ex.optJSONObject(i); if (e == null) continue;
            long t = e.optLong("time");
            if (t > now && (best == 0 || t < best)) { best = t; name = e.optString("name"); }
        }
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_countdown);
            Widgets.bindCountdown(c, rv, name, best, Widgets.theme(c, id));
            m.updateAppWidget(id, rv);
        }
    }
    @Override public void onDeleted(Context c, int[] ids) {
        android.content.SharedPreferences.Editor e = c.getSharedPreferences(Widgets.PREFS, 0).edit();
        for (int id : ids) e.remove("theme_" + id);
        e.apply();
    }
}
