package com.plandeck.app;
public class UpcomingTodoProvider extends TodoBase { @Override String mode() { return "upcoming"; } }
