package com.plandeck.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.telecom.TelecomManager;
import java.util.HashSet;
import java.util.Set;

/** Focus lock: while a session runs, blocked apps are sent straight back to Academic Planner. */
public class FocusLockService extends Service {
    static final String PREFS = "focuslock", CH = "focus_lock";
    private final Handler h = new Handler(Looper.getMainLooper());
    private long end, lastTs, lastBack;
    private String cur = "", mode = "all";
    private boolean strict;
    private final Set<String> apps = new HashSet<>();
    private final Runnable tick = new Runnable() {
        @Override public void run() { loop(); h.postDelayed(this, 700); }
    };

    public static long endOf(Context c) { return c.getSharedPreferences(PREFS, 0).getLong("end", 0); }
    public static boolean active(Context c) { return endOf(c) > System.currentTimeMillis(); }
    public static boolean strictOn(Context c) { return active(c) && c.getSharedPreferences(PREFS, 0).getBoolean("strict", false); }
    public static String modeOf(Context c) { return c.getSharedPreferences(PREFS, 0).getString("mode", "all"); }

    public static void start(Context c, long end, String mode, String apps, boolean strict) {
        c.getSharedPreferences(PREFS, 0).edit().putLong("end", end).putString("mode", mode)
            .putString("apps", apps).putBoolean("strict", strict).apply();
        Intent i = new Intent(c, FocusLockService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    public static void stop(Context c) {
        c.getSharedPreferences(PREFS, 0).edit().putLong("end", 0).putBoolean("strict", false).apply();
        c.stopService(new Intent(c, FocusLockService.class));
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        android.content.SharedPreferences p = getSharedPreferences(PREFS, 0);
        end = p.getLong("end", 0); mode = p.getString("mode", "all"); strict = p.getBoolean("strict", false);
        apps.clear();
        for (String a : p.getString("apps", "").split(",")) if (!a.isEmpty()) apps.add(a);
        if (end <= System.currentTimeMillis()) { stopSelf(); return START_NOT_STICKY; }
        Notification n = notif();
        if (Build.VERSION.SDK_INT >= 34) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(7001, n);
        lastTs = System.currentTimeMillis() - 60000;
        h.removeCallbacks(tick);
        h.post(tick);
        return START_STICKY;
    }

    @Override public void onDestroy() { h.removeCallbacks(tick); super.onDestroy(); }

    private Notification notif() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Focus lock", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CH);
        } else b = new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT;
        b.setSmallIcon(R.drawable.ic_stat_icon).setContentTitle(strict ? "Strict focus lock is on" : "Focus lock is on")
            .setContentText("sel".equals(mode) ? "Your chosen apps are blocked until the session ends" : "Other apps are blocked until the session ends")
            .setOngoing(true).setContentIntent(PendingIntent.getActivity(this, 0, open, fl));
        if (Build.VERSION.SDK_INT >= 24) b.setWhen(end).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true);
        return b.build();
    }

    /** "all" mode: only these may be used. */
    private boolean allowed(String p) {
        if (p == null || p.isEmpty() || p.equals(getPackageName()) || p.equals("com.android.systemui") || p.equals("android")) return true;
        if (p.contains("incallui") || p.contains("dialer") || p.contains("emergency") || p.equals("com.android.server.telecom")) return true;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                TelecomManager t = (TelecomManager) getSystemService(TELECOM_SERVICE);
                if (t != null && p.equals(t.getDefaultDialerPackage())) return true;
            }
            String ime = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
            if (ime != null && ime.startsWith(p + "/")) return true;
        } catch (Exception e) { }
        return false;
    }

    /** "sel" mode: only the chosen apps (and Settings when strict, so the lock cannot be switched off) are blocked. */
    private boolean blocked(String p) {
        if (p == null || p.isEmpty() || p.equals(getPackageName())) return false;
        if (apps.contains(p)) return true;
        return strict && p.equals("com.android.settings");
    }

    private void loop() {
        long now = System.currentTimeMillis();
        if (now >= end) { finish(); return; }
        try {
            UsageStatsManager u = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            UsageEvents ev = u.queryEvents(lastTs, now);
            lastTs = now;
            UsageEvents.Event e = new UsageEvents.Event();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) cur = e.getPackageName();
            }
        } catch (Exception e) { return; }
        boolean ok = "sel".equals(mode) ? !blocked(cur) : allowed(cur);
        if (ok || now - lastBack < 1200) return;
        lastBack = now;
        try {
            startActivity(new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } catch (Exception e) { }
    }

    private void finish() {
        getSharedPreferences(PREFS, 0).edit().putLong("end", 0).putBoolean("strict", false).apply();
        h.removeCallbacks(tick);
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
            b.setSmallIcon(R.drawable.ic_stat_icon).setContentTitle("Focus session complete").setContentText("Nice work. Your apps are unlocked.").setAutoCancel(true);
            nm.notify(7002, b.build());
        } catch (Exception e) { }
        stopForeground(true);
        stopSelf();
    }
}
