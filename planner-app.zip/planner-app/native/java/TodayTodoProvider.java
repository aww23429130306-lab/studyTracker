package com.plandeck.app;
public class TodayTodoProvider extends TodoBase { @Override String mode() { return "today"; } }
