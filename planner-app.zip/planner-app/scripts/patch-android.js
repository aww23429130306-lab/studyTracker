// Run after `npx cap add android`: copies the native widget/gallery code into the generated project.
const fs=require('fs'),path=require('path');
const PKG='com.plandeck.app',A='android/app/src/main';
const cp=(from,to)=>{fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(from,to)};
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
walk('native/java').forEach(f=>cp(f,path.join(A,'java',PKG.replace(/\./g,'/'),path.basename(f))));
walk('native/res').forEach(f=>cp(f,path.join(A,'res',path.relative('native/res',f))));
let m=fs.readFileSync(path.join(A,'AndroidManifest.xml'),'utf8');
if(!m.includes('MainCountdownProvider')){
  if(!m.includes('xmlns:tools'))m=m.replace('<manifest ','<manifest xmlns:tools="http://schemas.android.com/tools" ');
  m=m.replace('</application>',fs.readFileSync('native/manifest-application.xml','utf8')+'\n    </application>');
  m=m.replace('</manifest>',fs.readFileSync('native/manifest-permissions.xml','utf8')+'\n</manifest>');
  fs.writeFileSync(path.join(A,'AndroidManifest.xml'),m);
}
// stable signing key (Google sign-in is tied to its fingerprint) and the Google sign-in library
const gp=path.join('android','app','build.gradle');
let g=fs.readFileSync(gp,'utf8');
if(!g.includes('plandeck.keystore')){
  g=g.replace(/android\s*\{/,m=>m+"\n    signingConfigs {\n        debug {\n            storeFile file('plandeck.keystore')\n            storePassword 'plandeck123'\n            keyAlias 'plandeck'\n            keyPassword 'plandeck123'\n        }\n    }");
  g=g.replace(/\ndependencies\s*\{/,"\ndependencies {\n    implementation 'com.google.android.gms:play-services-auth:21.2.0'\n    implementation 'com.google.mlkit:text-recognition:16.0.1'");
  fs.writeFileSync(gp,g);
  fs.copyFileSync('native/plandeck.keystore',path.join('android','app','plandeck.keystore'));
}
console.log('Native widget code installed');
