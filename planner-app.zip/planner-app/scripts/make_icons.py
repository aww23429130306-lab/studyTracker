# Builds Academic Planner launcher icons from icon.png: adaptive icon (logo on navy) + legacy square/round icons.
import os, shutil
from PIL import Image, ImageDraw
BG='#FDFDFD'
base='android/app/src/main/res'
src=Image.open('icon.png').convert('RGBA')
for d,n in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
    p=f'{base}/mipmap-{d}'; os.makedirs(p,exist_ok=True)
    sq=src.resize((n,n),Image.LANCZOS); sq.save(f'{p}/ic_launcher.png')
    m=Image.new('L',(n*4,n*4),0); ImageDraw.Draw(m).ellipse((0,0,n*4-1,n*4-1),fill=255); m=m.resize((n,n),Image.LANCZOS)
    rd=Image.new('RGBA',(n,n),(0,0,0,0)); rd.paste(sq,(0,0),m); rd.save(f'{p}/ic_launcher_round.png')
    f=n*108//48                      # adaptive foreground layer is 108dp
    fg=Image.new('RGBA',(f,f),(0,0,0,0)); s=int(f*0.78)
    fg.paste(src.resize((s,s),Image.LANCZOS),((f-s)//2,(f-s)//2)); fg.save(f'{p}/ic_launcher_foreground.png')
for junk in ('drawable-v24/ic_launcher_foreground.xml','drawable/ic_launcher_background.xml'):
    try: os.remove(f'{base}/{junk}')
    except OSError: pass
os.makedirs(f'{base}/mipmap-anydpi-v26',exist_ok=True)
for name in ('ic_launcher','ic_launcher_round'):
    open(f'{base}/mipmap-anydpi-v26/{name}.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n')
open(f'{base}/values/ic_launcher_background.xml','w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">'+BG+'</color>\n</resources>\n')
